/*Caleb Harris
 * CS1150 (M/W)
 * Due: Jan 27, 2021
 * Assignment#1
 * This program demonstrates knowledge of basic program structure
 * by printing paragraphs that give the instructor information 
 * about myself and practices some basic arithmetic in Java.
 */
public class HarrisCalebAssignment1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("I am very passionate about many aspects of information"
				+ "technology");
	}//main

}//Assignment 1
