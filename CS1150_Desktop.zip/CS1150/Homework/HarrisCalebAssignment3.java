package Homework;

/*
Caleb Harris
CS1150 (M/W)
Due: Feb 7, 2021
Assignment#3
This program will help me learn how to utilize nested if statements
to computer the cost of a flight and output the information 
regarding the flight
*/

/*
		****Psuedocode****
*	1. Display a menu of destinations:
		a. Sydney, Australia             - 1750.00
		b. London, England               - 1300.00
		c. Frankfurt, Germany            - 1450.00
		d. Gabo San Lucas, Mexico        - 550.00
	2. Read user input for their destination
		a. If destination is outside of values; output error
		b. Else prompt user for number of checked and carry on bags
			i. If bags != number allowed; output error
			ii. Else display following info (format):
				1) Destination city
				2) Flight cost
				3) Baggage cost
				4) Total cost
*/

import java.util.Scanner;

public class HarrisCalebAssignment3 
{
	public static void main(String[] args)
	{
		//define constants
		final String DESTINATION1 = "Sydney, Australia";
		final String DESTINATION2 = "London, England";
		final String DESTINATION3 = "Frankfurt, Germany";
		final String DESTINATION4 = "Gabo San Lucas, Mexico";
		final double DESTINATION1COST = 1750.00;
		final double DESTINATION2COST = 1300.00;
		final double DESTINATION3COST = 1450.00;
		final double DESTINATION4COST = 550.00;
		final double CARRYON_COST = 35.00;
		final double CHECKED_BAG_COST = 25.00;
		
		//display table of options
		System.out.printf("%27s%n", "CS1150 Airline Program");
		System.out.println("--------------------------------------------");
		System.out.printf(" Destination: " + "%25s", "Cost: ");
		System.out.printf("%n%n" + "1)" + DESTINATION1 + "%16s%.2f", "$" + "", DESTINATION1COST);
		System.out.printf("%n" + "2)" + DESTINATION2 + "%18s%.2f", "$" + "", DESTINATION2COST);
		System.out.printf("%n" + "3)" + DESTINATION3 + "%15s%.2f", "$" + "", DESTINATION3COST);
		System.out.printf("%n" + "4)" + DESTINATION4 + "%11s%.2f", "$" + "", DESTINATION4COST);
		
		//prompt user for choice of destination
		System.out.printf("%n" + "--------------------------------------------");
		System.out.printf("%n" + "Choose your desination (1 - 4): ");
		Scanner userInput = new Scanner (System.in);
		int destinationChoice = userInput.nextInt();
		
		//conditional: is the value correct?
		if ((destinationChoice <= 4) && (destinationChoice >= 1))
			
		{
			//prompt user for checked bags
			System.out.printf("%n" + "Please enter how many checked bags you have (0 - 4 allowed): ");
			int checkedBags = userInput.nextInt();
			
			//conditional: are the amount of checked bags allowed?
			if ((checkedBags >= 0) && (checkedBags <= 4))
			{
				//prompt user for carry on bags
				System.out.printf("%n" + "Please enter how many carry on bags you have (0 - 1 allowed): ");
				int carryOnBag = userInput.nextInt();
				
				//conditional: is the amount of carry ons allowed?
				if ((carryOnBag == 0) || (carryOnBag == 1))
				{
					//Output block
					System.out.printf("%n" + "--------------------------------------------");
					
					//Destination Output
					if (destinationChoice == 1)
					{
						System.out.printf("%n" + "Destination: " + DESTINATION1);
					}
					else if (destinationChoice == 2)
					{
						System.out.printf("%n" + "Destination: " + DESTINATION2);
					}
					else if (destinationChoice == 3)
					{
						System.out.printf("%n" + "Destination: " + DESTINATION3);
					}
					else if (destinationChoice == 4)
					{
						System.out.printf("%n" + "Destination: " + DESTINATION4);
					}
					
					//Checked Bags Amount
					System.out.printf("%n" + "Checked Bags: " + checkedBags);
					
					//Carry on amount
					System.out.printf("%n" + "Carry On Bags: " + carryOnBag);
					
					//Baggage Cost
					double baggageCost = ((checkedBags * CHECKED_BAG_COST) + (carryOnBag * CARRYON_COST));
					System.out.printf("%n" + "Baggage Cost: " + "$");
					System.out.printf("%.2f", baggageCost);
					
					//Display flight total
					if (destinationChoice == 1)
					{
						System.out.printf("%n" + "Flight Cost: " + "$");
						System.out.printf("%.2f", DESTINATION1COST);
					}
					else if (destinationChoice == 2)
					{
						System.out.printf("%n" + "Flight Cost: " + "$");
						System.out.printf("%.2f", DESTINATION2COST);
					}
					else if (destinationChoice == 3)
					{
						System.out.printf("%n" + "Flight Cost: " + "$");
						System.out.printf("%.2f", DESTINATION3COST);
					}
					else if (destinationChoice == 4)
					{
						System.out.printf("%n" + "Flight Cost: " + "$");
						System.out.printf("%.2f", DESTINATION4COST);
					}
					
					System.out.printf("%n" + "--------------------------------------------");
					
					//computer and display total
					if (destinationChoice == 1)
					{
						double totalCost1 = DESTINATION1COST + baggageCost;
						System.out.printf("%n" + "Total: " + "$");
						System.out.printf("%.2f", totalCost1);
					}
					else if (destinationChoice == 2)
					{
						double totalCost2 = DESTINATION2COST + baggageCost;
						System.out.printf("%n" + "Total: " + "$");
						System.out.printf("%.2f", totalCost2);
					}
					else if (destinationChoice == 3)
					{
						double totalCost3 = DESTINATION3COST + baggageCost;
						System.out.printf("%n" + "Total: " + "$");
						System.out.printf("%.2f", totalCost3);
					}
					else if (destinationChoice == 4)
					{
						double totalCost4 = DESTINATION4COST + baggageCost;
						System.out.printf("%n" + "Total: " + "$");
						System.out.printf("%.2f", totalCost4);
					}
				}
				else 
				{
					System.out.printf("%n" + "Only 0 - 1 carry on bags allowed! Please run the program again!");
				}
			}
			else 
			{
				System.out.printf("%n" + "Only 0 - 4 checked bags allowed! Please run the program again!");
			}
			
		}
		else 
		{
			System.out.printf("%n" + "Please run the program again and select a valid destination!");
		}
	
	}
}
