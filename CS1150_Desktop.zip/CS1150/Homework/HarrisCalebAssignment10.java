package Homework;

/*
 * By: Caleb Harris
 * CS1150 - 001 (m/w)
 * Due: April 17, 2021
 * Problem Statement: This program will create several athlete objects, 
 * place them into an array, perform manipulations on these athletes, then 
 * create a team object, place athletes objects into the team's array of 
 * athletes, and perform similar manipulations on the array in the team.
 * 
 * Psuedocode:
 * Assignment10 (main) Class:
	1. Create an array to store athletes
	2. Add each athlete to the array
	3. Print each athletes in the array using a for loop to iterate through the array and using the getters in athlete class to print the name and world ranking of the athletes
	4. Determine which athlete is the highest ranked and display their name and world ranking
	5. Create 1 team object
	6. Send constructor the max number of athletes which is 25
	7. Add each athlete created in part 1 to the team using addAthlete public method
	8. Print each athletes name using and world ranking using the displayAthletes public method
	9. Find the highest ranked athlete using public method findHighestRanked and display the name and world ranking of athlete
	
Find Highest Ranked Athlete Method in Team class:
	1. Pass athlete object into method
	2. 
	x. Return highestRankedAthlete athlete object
 */

public class HarrisCalebAssignment10 {

	public static void main(String[] args) {
		
		//create array to store athletes
		Athlete[] athleteArray = new Athlete[9];
		
		//creates athlete objects
		Athlete athlete1 = new Athlete("Haley Anderson   ", 26);
		Athlete athlete2 = new Athlete("Regan Smith     ", 2);
		Athlete athlete3 = new Athlete("Katie Ledecky   ", 3);
		Athlete athlete4 = new Athlete("Ryan Murphy     ", 5);
		Athlete athlete5 = new Athlete("Annie Lazor     ", 7);
		Athlete athlete6 = new Athlete("Caeleb Dressel  ", 1);
		Athlete athlete7 = new Athlete("Katie Drabot    ", 6);
		Athlete athlete8 = new Athlete("Luca Urlando    ", 3);
		Athlete athlete9 = new Athlete("Ashley Twitchell ", 12);
		
		//stores athletes in array
		athleteArray[0] = athlete1;
		athleteArray[1] = athlete2;
		athleteArray[2] = athlete3;
		athleteArray[3] = athlete4;
		athleteArray[4] = athlete5;
		athleteArray[5] = athlete6;
		athleteArray[6] = athlete7;
		athleteArray[7] = athlete8;
		athleteArray[8] = athlete9;
		
		//print each athlete's name and ranking in array
		System.out.println("*********************************************************************");
		System.out.println("Athlete Array");
		System.out.println("*********************************************************************\n");
		System.out.println("Athlete:				World Ranking");
		System.out.println("-----------------------------------------------------");
		for (int i = 0; i < athleteArray.length; i++) {
			System.out.printf(athleteArray[i].getName() + "%28s", athleteArray[i].getRanking() + "\n");
		}
		
		//determine which is highest ranked and display their name and ranking
		Athlete highestRankingAthlete = null;
		int highestRanking = 30;
		for (int i = 0; i < athleteArray.length; i++) {
			if (athleteArray[i].getRanking() < highestRanking) {
				highestRanking = athleteArray[i].getRanking();
				highestRankingAthlete = athleteArray[i];
			}
		}
		
		System.out.println("\nThe highest ranking athlete in the array of athletes: \n-----------------------------------------------------\nAthlete: " + highestRankingAthlete.getName()
		+ "\nRanking: " + highestRankingAthlete.getRanking() + "\n\n");
		
		//create team object
		Team team1 = new Team(25);
		
		//adds each athlete to the team
		for (int i = 0; i < athleteArray.length; i++) {
			team1.addAthlete(athleteArray[i]);
		}
		
		//displays athletes from team
		System.out.println("*********************************************************************");
		System.out.println("Athletes in Team Object");
		System.out.println("*********************************************************************\n");
		team1.displayAthletes();
		
		//displays the highest ranking athlete from the team
		System.out.println("\nThe highest ranking athlete in the array of athletes: \n-----------------------------------------------------\nAthlete: " + team1.findHighestRankedAthlete().getName()
		+ "\nRanking: " + team1.findHighestRankedAthlete().getRanking() + "\n\n");

	}//end main

}//end HarrisCalebAssignment10

class Athlete {
	
	//enter private data fields
	private String name;
	private int worldRanking;
	
	//public methods
	//-----
	//athlete constructor
	public Athlete (String name, int worldRanking) {
		this.name = name;
		this.worldRanking = worldRanking;
	}
	
	//getter for name
	public String getName() {
		
		return name;
		
	}
	
	//getter for ranking
	public int getRanking() {
		
		return worldRanking;
		
	}
	
}//end Athlete

class Team {
	
	//private data fields
	private Athlete[] athleteArray_Team;
	private int currentNumAthletes;
	
	//public methods
	//-----
	//team constructor
	public Team (int maxNumAthletes) {
		
		athleteArray_Team = new Athlete[maxNumAthletes];
		currentNumAthletes = 0;
		
	}
	
	//setter for adding athletes to team
	public void addAthlete (Athlete athleteToAdd) {
		
		//adds incoming athlete to team's array of athletes
		athleteArray_Team[currentNumAthletes] = athleteToAdd;
		currentNumAthletes++;
	}
	
	//finds and returns the highest ranked athlete in team's array of athletes
	public Athlete findHighestRankedAthlete() {
		
		Athlete highestRankedAthlete_Team = null;
		int highestRanking = 30;
		for (int i = 0; i < currentNumAthletes; i++) {
			if (athleteArray_Team[i].getRanking() < highestRanking) {
				highestRanking = athleteArray_Team[i].getRanking();
				highestRankedAthlete_Team = athleteArray_Team[i];
			}
		}
		return highestRankedAthlete_Team;
		
	}
	
	//displays all athletes in the team's array of athletes
	public void displayAthletes() {
		
		System.out.println("Athlete:				World Ranking");
		System.out.println("-----------------------------------------------------");
		for (int i = 0; i < currentNumAthletes; i++) {
			System.out.printf(athleteArray_Team[i].getName() + "%28s", athleteArray_Team[i].getRanking() + "\n");
		}
	}
	
}//end Team
