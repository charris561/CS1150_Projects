package Homework;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * By: Caleb Harris
 * CS1150 - 001 (m/w)
 * Due: April 23, 2021
 * Assignment 11
 * Problem Statement: Simulate a race between 6 objects and write the mileage of these objects to a file.
 * 
 * Main: needs to create 6 race cars, call createRaceCars method, call printRaceCars method, starts the race,
 * updates the car's milage every hour, calls the incrementMiles method and the getMiles method to do so,
 * calls printRaceCars again, calls findWinner, calls writeCarDetailsToFile.
 * methods (needs static keyword): 
 * -public static void createRaceCars (RaceCar[] raceCars)
 * -public static void printRaceCars (RaceCar[] raceCars)
 * -public static int findWinner (RaceCar[] raceCars)
 * -public static void writeCarDetailsToFile (RaceCar[] raceCars) throws IOException
 * 
 * Classes: 
 * -RaceCar ~ represent one race car
 * private data fields
 * 		-driver
 * 		-carNumber
 * 		-averageSpeed
 * 		-odometer
 * methods
 * 		-(constructor)public RaceCar(String driver, int carNumber, double averageSpeed)
 * 		-create getters for driver, carNumber, averageSpeed, odometer
 * 
 * -Odometer ~ represents the odometer in a race car
 * private data fields
 * 		-double miles
 * methods
 * 		-(constructor) public Odometer()
 * 		-create getter for miles
 * 		-public void incrementMiles(double milesTraveled)
 * 
 */

public class HarrisCalebAssignment11 {

	public static void main(String[] args) throws IOException {

		System.out.println("Race cars at start of race: ");
		// create array to store race cars
		RaceCar[] raceCars = new RaceCar[6];

		// creates race car objects and stores in array
		createRaceCars(raceCars);

		// prints the details for each race car in array
		printRaceCars(raceCars);

		// Start the race!

		// initializes variables needed for race
		System.out.println("\nAll drivers are ready; start the race!\n");
		boolean winnerFound = false;
		double timeElapsed = 0;
		int iteration = 0;

		// simulates the race
		while (!winnerFound) {

			// prints time elapsed in race
			timeElapsed = timeElapsed + 0.25;
			System.out.println("Time Elapsed = " + timeElapsed + " Hours");

			if (iteration % 4 == 0) {
				for (int i = 0; i < raceCars.length; i++) {
					raceCars[i].getOdometer().incrementMiles(raceCars[i].getaverageSpeed());
					if (raceCars[i].getOdometer().getMiles() >= 500) {
						winnerFound = true;
					}
				}
			}

			iteration++;
		} // while

		// prints the details of each race car post race
		printRaceCars(raceCars);

		// finds the winner and displays their name and miles traveled
		int winnerIndex = findWinner(raceCars);
		System.out.println("\nThe winner is " + raceCars[winnerIndex].getDriver() + " with "
				+ raceCars[winnerIndex].getOdometer().getMiles() + " miles driven!\n");
		
		//writes the details for each car to a file
		writeCarDetailsToFile(raceCars);

	} // end main

	public static void createRaceCars(RaceCar[] raceCars) {
		// creates RaceCar objects
		RaceCar raceCar1 = new RaceCar("Shrek", 18, 77);
		RaceCar raceCar2 = new RaceCar("Fiona", 8, 85);
		RaceCar raceCar3 = new RaceCar("Donkey", 17, 117);
		RaceCar raceCar4 = new RaceCar("Dragon", 42, 81);
		RaceCar raceCar5 = new RaceCar("Farquaad", 14, 109);
		RaceCar raceCar6 = new RaceCar("Pinocchio", 19, 75);

		// stores RaceCars into array
		raceCars[0] = raceCar1;
		raceCars[1] = raceCar2;
		raceCars[2] = raceCar3;
		raceCars[3] = raceCar4;
		raceCars[4] = raceCar5;
		raceCars[5] = raceCar6;
	}// end createRaceCars

	public static void printRaceCars(RaceCar[] raceCars) {

		// prints out the details for each car in array
		System.out.println("\n---------------------------------------------------------------------------------------");
		System.out.println("   Driver:		Car Number:		Average Speed:		Miles Driven:");
		System.out.println("---------------------------------------------------------------------------------------");
		for (int i = 0; i < raceCars.length; i++) {
			System.out.printf("%9s		%2d			%4.2f			", raceCars[i].getDriver(),
					raceCars[i].getCarNumber(), raceCars[i].getaverageSpeed());
			System.out.println(raceCars[i].getOdometer().getMiles());
		}

	}// end printRaceCars

	public static int findWinner(RaceCar[] raceCars) {

		// finds the racer with the highest miles traveled and returns their array index
		int winnerIndex = 0;
		double mostMiles = 0;
		for (int i = 0; i < raceCars.length; i++) {
			if (raceCars[i].getOdometer().getMiles() > mostMiles) {
				mostMiles = raceCars[i].getOdometer().getMiles();
				winnerIndex = i;
			}
		}

		return winnerIndex;
	}// end findWinner

	public static void writeCarDetailsToFile(RaceCar[] raceCars) throws IOException {

		// Setup the file reference variable to refer to a text file.
		// Assignment11.txt is the file that will be created on your hard drive.
		File fileName = new File("Assignment11.txt");

		// Create the file that the race cars will be written to.
		// This means connect Assignment11.txt on your hard drive to the 
		// variable resultsFile in the code.
		PrintWriter resultsFile = new PrintWriter(fileName);

		// Write the details for each car to the file
		resultsFile.println("Race Car Details");
		for (int i = 0; i < raceCars.length; i++) {
			resultsFile.println(raceCars[i].getCarNumber());
			resultsFile.println(raceCars[i].getDriver());
			resultsFile.println(raceCars[i].getOdometer().getMiles());
			resultsFile.println();
		}
		resultsFile.close();

		// Shows where the file is located on your hard drive 		
		// Locate the file in your CS1150 eclipse workspace on your hard drive.
		// Compare the file contents to what is in the code below.
		System.out.println("Find the file here " + fileName.getAbsolutePath());
		System.out.println();

	} // writeCarDetailsToFile

} // end HarrisCalebAssignment11

class RaceCar {

	// private data fields
	private String driver;
	private int carNumber;
	private double averageSpeed;
	private Odometer odometer;

	// public methods
	// *********************
	// constructor
	public RaceCar(String driver, int carNumber, double averageSpeed) {
		this.driver = driver;
		this.carNumber = carNumber;
		this.averageSpeed = averageSpeed;
		odometer = new Odometer();
	}

	// getters
	public String getDriver() {
		return driver;
	}

	public int getCarNumber() {
		return carNumber;
	}

	public double getaverageSpeed() {
		return averageSpeed;
	}

	public Odometer getOdometer() {
		return odometer;
	}

} // end RaceCar

class Odometer {

	// private data fields
	private double miles;

	// public methods
	// *********************
	// constructor
	public Odometer() {
		miles = 0;
	}

	// getter for miles
	public double getMiles() {
		return miles;
	}

	// increments miles
	public void incrementMiles(double milesTraveled) {
		miles = miles + milesTraveled;
	}

} // end Odometer
