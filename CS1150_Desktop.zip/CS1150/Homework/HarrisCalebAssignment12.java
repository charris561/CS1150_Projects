package Homework;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

/*
 * By: Caleb Harris
 * CS1150 - 001 (m/w)
 * Due: April 28, 2021
 * Assignment 12
 * Problem Statement: This program will use a superclass, subclasses, and polymorphism to read in information about animals from
 * a file and make the animals do certain things
 */

public class HarrisCalebAssignment12 {

	public static void main(String[] args) throws IOException {

		// setup the file reference variable to refer to the text file
		File inputFileName = new File("assignment12.txt");

		// open file for reading by creating a scanner for file
		Scanner inputFile = new Scanner(inputFileName);

		// create an array to store animals
		Animal[] animals = new Animal[6];

		// create loop to fill array with animals information from file
		for (int i = 0; i < animals.length; i++) {
			String animalType = inputFile.next();

			if (animalType.equalsIgnoreCase("Panther")) {
				Animal animal = new Panther(inputFile.next(), inputFile.nextDouble(), inputFile.next(),
						inputFile.next());
				animals[i] = animal;
			} else if (animalType.equalsIgnoreCase("Penguin")) {
				Animal animal = new Penguin(inputFile.next(), inputFile.nextDouble(), inputFile.next(),
						inputFile.next());
				animals[i] = animal;
			} else if (animalType.equalsIgnoreCase("Bear")) {
				Animal animal = new Bear(inputFile.next(), inputFile.nextDouble(), inputFile.next(), inputFile.next());
				animals[i] = animal;
			} else if (animalType.equalsIgnoreCase("Wolf")) {
				Animal animal = new Wolf(inputFile.next(), inputFile.nextDouble(), inputFile.next(), inputFile.next());
				animals[i] = animal;
			}

		} // for

		// display output for animal array
		for (int i = 0; i < animals.length; i++) {

			// checks to see what type of animal is in the object in array and displays what
			// it is
			if (animals[i] instanceof Panther) {
				System.out.printf("Animal[%d] is a Panther\n", i);
			} else if (animals[i] instanceof Penguin) {
				System.out.printf("Animal[%d] is a penguin\n", i);
			} else if (animals[i] instanceof Bear) {
				System.out.printf("Animal[%d] is a Bear\n", i);
			} else if (animals[i] instanceof Wolf) {
				System.out.printf("Animal[%d] is a Wolf\n", i);
			}

			// calls methods to display animal's behavior and its information
			System.out.println(animals[i].toString());
			animals[i].eat();
			animals[i].sleep();
			animals[i].swim();

			System.out.printf("\n");
			
			inputFile.close();

		} // for

	}// end main

}// HarrisCalebAssignment12

class Animal {

	// private data fields
	private String name;
	private double weight;
	private String food;
	private String location;

	/*
	 * Public Methods
	 */
	// constructor
	public Animal(String name, double weight, String food, String location) {
		this.name = name;
		this.weight = weight;
		this.food = food;
		this.location = location;
	}

	// getters
	public String getName() {
		return name;
	}

	public double getWeight() {
		return weight;
	}

	public String getFood() {
		return food;
	}

	public String getLocation() {
		return location;
	}

	// Simulates animals behavior
	public void eat() {
		System.out.println("Animal is eating");
	}

	public void sleep() {
		System.out.println("Animal is sleeping - Do not disturb!");
	}

	public void swim() {
		System.out.println("Animal is swimming");
	}

}// Animal

class Panther extends Animal {

	/*
	 * Public Methods
	 */
	// Constructor
	public Panther(String name, double weight, String food, String location) {
		super(name, weight, food, location);
	}

	// overrides the eat() method
	@Override
	public void eat() {
		System.out.println("Panther is eating meat");
	}

	// overrides the sleep() method
	@Override
	public void sleep() {
		System.out.println("Panther is sleeping");
	}

	// overrides the toString() method to display the objects name, weight, and
	// location
	@Override
	public String toString() {

		return "Panther " + getName() + " weighs " + getWeight() + " lbs and is located at " + getLocation();

	}

}// Panther

class Penguin extends Animal {

	/*
	 * Public Methods
	 */
	// Constructor
	public Penguin(String name, double weight, String food, String location) {
		super(name, weight, food, location);
	}

	// overrides the eat() method
	@Override
	public void eat() {
		System.out.println("Penguin is eating fish");
	}

	// overrides the swim() method
	@Override
	public void swim() {
		System.out.println("Penguin is swimming");
	}

	// overrides the toString() method to display the objects name, weight, and
	// location
	@Override
	public String toString() {

		return "Penguin " + getName() + " weighs " + getWeight() + " lbs and is located at " + getLocation();

	}

}// Penguin

class Bear extends Animal {

	/*
	 * Public Methods
	 */
	// Constructor
	public Bear(String name, double weight, String food, String location) {
		super(name, weight, food, location);
	}

	// overrides the eat() method
	@Override
	public void eat() {
		System.out.println("Bear is eating honey");
	}

	// overrides the sleep() method
	@Override
	public void sleep() {
		System.out.println("Bear is sleeping");
	}

	// overrides the swim() method
	@Override
	public void swim() {
		System.out.println("Bear is swimming");
	}

	// overrides the toString() method to display the objects name, weight, and
	// location
	@Override
	public String toString() {

		return "Bear " + getName() + " weighs " + getWeight() + " lbs and is located at " + getLocation();

	}

}// Bear

class Wolf extends Animal {

	/*
	 * Public Methods
	 */
	// Constructor
	public Wolf(String name, double weight, String food, String location) {
		super(name, weight, food, location);
	}

	// overrides the toString() method to display the objects name, weight, and
	// location
	@Override
	public String toString() {

		return "Wolf " + getName() + " weighs " + getWeight() + " lbs and is located at " + getLocation();

	}

}// Wolf
