package Homework;

/*
 * By: Caleb Harris
 * CS 1150 - 001 (m/w)
 * Due: March 10, 2021
 * Assignment #6
 * Problem Statement: The problem that will be solved by this program is to simulate a bank and present the user with multiple loans with different interest rates. 
 * 
 * ****Psuedocode****
 * 	1. Initialize constants:
		   final int MIN_AUTO = 5000;
		   final int MAX_AUTO = 100000;
		   final double AUTO_LOW_RATE = 2.0;
		   final double AUTO_HIGH_RATE = 4.0;
	2. Display greeting
	3. Display options for bank loans
	4. Prompt user to select type of loan 1,2,or3
	5. While options not equal to 1, 2, or 3; ask for valid input
	6. Prompt user to enter loan amount 
		a. For auto: 5000 - 100000
		b. For home: 100000 - 1000000
	7. Initialize variables for interest and increment value to use in for loop below
	8. If auto
			i. While loan is not within 5000 to 100000; ask for valid input
		a. Prompt user for loan term
			i. While loan is not 5, 6, or 7 years; ask for valid input
		b. Use variables stated in 7 for for loop
		c. For ( i = 2; i <= 4; i = i + 0.25) 
			i. Compute monthly and total using above formulas and display them
	9. If home
			i. While loan is not within 100000 to 1,000,000; ask for valid input
		a. Prompt user for loan term
			i. While loan is not 15 or 30 years; ask for valid input
		b. Use variables stated in 7 for for loop
		c. For (I = 2; I <= 4; I = I + 0.25)
			i. Computer monthly and total payments and display them
	10. Else output goodbye
 * 
 */

import java.util.Scanner;

public class HarrisCalebAssignment6 
{

	public static void main(String[] args) 
	{
		Scanner input = new Scanner (System.in);
		
		//initialize constants
		final int MIN_AUTO = 5000;
		final int MAX_AUTO = 100000;
		final double AUTO_LOW_RATE = 2.0;
		final double AUTO_HIGH_RATE = 4.0;
		final double HOME_LOW_RATE = 4.0;
		final double HOME_HIGH_RATE = 5.5;
		final int MIN_HOME = 100000;
		final int MAX_HOME = 1000000;
		final int AUTO_TERM_MIN = 5;
		final int AUTO_TERM_MAX = 7;
		final double RATE_INCREMENT = 0.25;
		
		//display greeting
		System.out.println("**********************************************");
		System.out.println("Welcome to CS1150 Banking!");
		System.out.println("**********************************************\n");
		
		//main loop that allows user to view loans as many times as desired
		boolean viewingLoans = true;
		while (viewingLoans == true)
		{
		
		//display options for bank loans
		System.out.println("\n--------------------------");
		System.out.println("Loan Options:");
		System.out.println("--------------------------");
		System.out.println("1) Auto Loan");
		System.out.println("2) Home Loan");
		System.out.println("3) Exit");
		System.out.println("--------------------------\n");
		
		//prompt user for menu choice
		System.out.println("Select one of the above options: ");
		int menuChoice = input.nextInt();
		
		//check for valid input
		while (menuChoice != 1 && menuChoice != 2 && menuChoice != 3)
		{
			System.out.println("Please enter a valid menu option: ");
			System.out.println("1) Auto Loan");
			System.out.println("2) Home Loan");
			System.out.println("3) Exit");
			menuChoice = input.nextInt();
		}
		
		//checks if user wants to exit
		if (menuChoice != 3)
		{
			//auto loan conditional
			if (menuChoice == 1)
			{
				//prompts user for loan amount
				System.out.println("You have chosen an Auto Loan! Please enter the amount for your loan between $" + MIN_AUTO + " - $" + MAX_AUTO);
				int loanAmount = input.nextInt();
				
				//checks to see if loan is within 5,000 - 100,000
				while (loanAmount < MIN_AUTO || loanAmount > MAX_AUTO)
				{
					System.out.println("Please enter a valid loan amount between $5,000 and $100,000");
					loanAmount = input.nextInt();
				}
				
				//prompts user for loan term
				System.out.println("Please enter the term for your loan (available term lengths are 5, 6, and 7 years)");
				int termChoice = input.nextInt();
				
				//checks for valid term length
				while (termChoice < AUTO_TERM_MIN || termChoice > AUTO_TERM_MAX)
				{
					System.out.println("Please enter a valid term length for your loan! (available term lengths are 5, 6, and 7 years)");
					termChoice = input.nextInt();
				}
				
				System.out.printf("\n");
				System.out.println("Interest rate:			Monthly Payment:			TotalPayments:\n");
				System.out.println("--------------------------------------------------------------------------------------------------------\n");
				
				//computes and displays results
				for (double autoAnnualRate = AUTO_LOW_RATE; autoAnnualRate <= AUTO_HIGH_RATE; autoAnnualRate = autoAnnualRate + RATE_INCREMENT)
				{
					//computes values
					double monthlyIntRate = (autoAnnualRate / 100) / 12;
					double monthlyPayments = (loanAmount * monthlyIntRate) / (1 - ( 1 / (Math.pow(1 + monthlyIntRate, termChoice * 12))));
					double totalPayments = (monthlyPayments * 12) * termChoice;
					
					//output results
					System.out.printf("%.2f", autoAnnualRate);
					System.out.print("				");
					System.out.printf("%.2f", monthlyPayments);
					System.out.print("					");
					System.out.printf("%.2f", totalPayments);
					System.out.print("\n");
					
				}
			}
			
			//home loan conditional
			if (menuChoice == 2)
			{
				//prompts user for loan amount
				System.out.println("You have chosen a Home Loan! Please enter the amount for your loan between $" + MIN_HOME + " - $" + MAX_HOME);
				int loanAmount = input.nextInt();
				
				//checks to see if loan is within 5,000 - 100,000
				while (loanAmount < MIN_HOME || loanAmount > MAX_HOME)
				{
					System.out.println("Please enter a valid loan amount between $100,000 and $1,000,000");
					loanAmount = input.nextInt();
				}
				
				//prompts user for loan term
				System.out.println("Please enter the term for your loan (available term lengths are 15 and 30 years)");
				int termChoice = input.nextInt();
				
				//checks for valid term length
				while (termChoice != 15 && termChoice != 30)
				{
					System.out.println("Please enter a valid term length for your loan! (available term lengths are 15 and 30 years)");
					termChoice = input.nextInt();
				}
				
				System.out.printf("\n");
				System.out.println("Interest rate:			Monthly Payment:			TotalPayments:\n");
				System.out.println("--------------------------------------------------------------------------------------------------------\n");
				
				//computes and displays results
				for (double homeAnnualRate = HOME_LOW_RATE; homeAnnualRate <= HOME_HIGH_RATE; homeAnnualRate = homeAnnualRate + RATE_INCREMENT)
				{
					//computes values
					double monthlyIntRate = (homeAnnualRate / 100) / 12;
					double monthlyPayments = (loanAmount * monthlyIntRate) / (1 - ( 1 / (Math.pow(1 + monthlyIntRate, termChoice * 12))));
					double totalPayments = (monthlyPayments * 12) * termChoice;
					
					//output results
					System.out.printf("%.2f", homeAnnualRate);
					System.out.print("				");
					System.out.printf("%.2f", monthlyPayments);
					System.out.print("					");
					System.out.printf("%.2f", totalPayments);
					System.out.print("\n");
					
				}
			}
		}
		else 
		{
			viewingLoans = false;
			System.out.println("Thank you for visiting CS1150 Bank! Have a great day!");
		}
		
		}
		
		input.close();

	}

}
