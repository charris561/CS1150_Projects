package Homework;

/*
Caleb Harris
CS1150 (M/W)
Due: Feb 4, 2021
Assignment#2
This program will help me develop and demonstrate
understanding of different data types, variables,
and using the scanner class to read input from a
user by creating a simple GPA calculator for two
classes.
*/

/*Psuedocode:
import scanner class
create scanner object
prompt user for their name
create String variable for their name
prompt user for their course 1 name
store course 1 name as String nameCourse1
prompt user for credit hours of course 1
store credit hours as int creditHoursCourse1
prompt user for projected grade A = 4, B = 3, C = 2,
	D = 1, F = 0
store projected grade for course1 as int gradeCourse1
calculate grade points and store as double
	eq. [ gradePointsCourse1 = creditHoursCourse1 *
	gradeCourse1 ]
repeat steps for second course
display results neatly in a table
	information needed on table:
	-course name
	-course grade
	-credit hours
	-grade points
	-total credit hours
	-total grade points
compute GPA
	eq. [ gpa = totalGradePoints / totalCreditHours ]
*/

import java.util.Scanner;

public class HarrisCalebAssignment2 
{

	public static void main(String[] args)
	{	
		
		//Create a scanner object for student name
		Scanner inputName = new Scanner (System.in);
		
		//Prompt user to input their name
		System.out.print("Enter your name here: ");
		String studentName = inputName.nextLine();
	
	//Course 1
		
		//Prompt user to input name of course 1
		Scanner courseInput1 = new Scanner (System.in);
		System.out.print("Enter the name of your first course: ");
		String courseName1 = courseInput1.next();
		
		//Prompt user for credit hours for course 1
		Scanner creditHoursInput1 = new Scanner (System.in);
		System.out.print("Enter the credit hours for course: ");
		int creditHours1 = creditHoursInput1.nextInt();
		
		//Prompt user for projected grade
		Scanner projGradeInput1 = new Scanner (System.in);
		System.out.print("Enter your projected grade in "
				+ "the course [ A = 4, B = 3, C = 2, D = 1, F = 0]");
		int projGrade1 = projGradeInput1.nextInt();
		//Conditional for if projected grade is inputed outside of range
		if ((projGrade1 < 0) || (projGrade1 > 4))
		{
			System.out.print("Error, please input a valid grade in the"
					+ "format: [ A = 4, B = 3, C = 2, D = 1, F = 0]");
		}
		
		//Calculate Grade Points
		double gradePoints1 = (creditHours1)/(projGrade1);
	
	//Course 2
		
		//Prompt user to input name of course 2
		Scanner courseInput2 = new Scanner (System.in);
		System.out.print("Enter the name of your second course: ");
		String courseName2 = courseInput2.next();
		
		//Prompt user for credit hours for course 2
		Scanner creditHoursInput2 = new Scanner (System.in);
		System.out.print("Enter the credit hours for course: ");
		int creditHours2 = creditHoursInput2.nextInt();
		
		//Prompt user for projected grade
		Scanner projGradeInput2 = new Scanner (System.in);
		System.out.print("Enter your projected grade in "
				+ "the course [ A = 4, B = 3, C = 2, D = 1, F = 0]");
		int projGrade2 = projGradeInput2.nextInt();
		//Conditional for if projected grade is inputed outside of range
		if ((projGrade2 < 0) || (projGrade2 > 4))
		{
			System.out.print("Error, please input a valid grade in the"
					+ "format: [ A = 4, B = 3, C = 2, D = 1, F = 0]");
		}
		
		//Calculate grade points
		double gradePoints2 = (creditHours2)/(projGrade2);
		
		//Display results in table
		System.out.println("----------------------------------------");
		System.out.println("Student Name:  " + studentName);
		System.out.println("\n");
		System.out.println("  Course 1: " + courseName1);
		System.out.println("  Credit Hours: " + creditHours1);
		System.out.println("  Projected Course Grade: " + projGrade1);
		System.out.println("  Grade Points: " + gradePoints1);
		
		System.out.println("\n");
		System.out.println("  Course 1: " + courseName2);
		System.out.println("  Credit Hours: " + creditHours2);
		System.out.println("  Projected Course Grade: " + projGrade2);
		System.out.println("  Grade Points: " + gradePoints2);
		System.out.println("\n");
		
		double totalGradePoints = gradePoints1 + gradePoints2;
		int totalCreditHours = creditHours1 + creditHours2;
		System.out.println("Total Grade Points: " + totalGradePoints);
		System.out.println("Total Credit Hours: " + totalCreditHours);
		
		//Computer GPA
		double gpa = totalGradePoints / totalCreditHours;
		System.out.println("GPA = " + gpa);
		
		//Close Scanner Objects
		inputName.close();
		courseInput1.close();
		courseInput2.close();
		creditHoursInput1.close();
		creditHoursInput2.close();
		projGradeInput1.close();
		projGradeInput2.close();
	}
	
}
