package Homework;

/*Caleb Harris
 * CS1150 (M/W)
 * Due: Jan 27, 2021
 * Assignment#1
 * This program demonstrates knowledge of basic program structure
 * by printing paragraphs that give the instructor information 
 * about myself and practices some basic arithmetic in Java.
 */
public class HarrisCalebAssignment1 {

	public static void main(String[] args) {
		// \n operator makes code go to next line. 
		System.out.println("Some information about me: \n\n"
				+ "    I am very passionate about many aspects of information \n"
				+ "technology. I have recently changed my major from mechanical \n"
				+ "engineering to computer science because I have developed a passion \n"
				+ "for information technology over the last year. This passion first \n"
				+ "came from watching many information technology videos on YouTube \n"
				+ "regarding building computers, computer technology, and technology \n"
				+ "currently being developed or products that may be available in the \n"
				+ "consumer market in the future. This passion was further cultivated \n"
				+ "by starting to work in information technology at the UCCS OIT \n"
				+ "Help Desk. This work gave me exposure into enterprise information \n"
				+ "technology and while my experience is very entry level, it made me \n"
				+ "want to pursue a career in this field. \n\n"
				+ "     While I am very passionate about information technology, I am \n"
				+ "also very passionate about computer gaming. Computer gaming for me \n"
				+ "has always been a way to relax and remove myself from the stresses \n"
				+ "of everyday life. Not to say that my life has been particularily \n"
				+ "hard, but I have always found comfort in video games. There is \n"
				+ "something very nice about immersing yourself in a world that is so \n"
				+ "different from your own. This also contributes to my interest in \n"
				+ "computer science because games are constructed by code as any other \n"
				+ "computer program. The way a narrative and story can be lived out \n"
				+ "through the annals of a computer program has always fascinated me. \n"
				+ "Although my main interest in these courses will be to pursue a career \n"
				+ "in computer science, I may also use these skills to modify games \n"
				+ "to personalize or create my own vision in a video game that already \n"
				+ "exists. \n\n"
				+ "     Aside from my passions within the realm of computer science, I \n"
				+ "also have many other hobbies! One such hobby would be hiking. I have \n"
				+ "grown up in Colorado and ever since I was a child,  I loved going \n"
				+ "hiking and being in nature. There is something very tranquil about \n"
				+ "getting away from the busy, bustling city that most of us call home. \n"
				+ "This also allows me to pursue my fitness goals. I also love to take \n"
				+ "my dogs with me hiking. They enjoy exploring the trails just as much \n"
				+ "as I do. I love many other outdoor activities but one of my main other \n"
				+ "outdoor hobbies would be mountain biking. While I have not been \n"
				+ "mountain biking in some time due to the constraints on my schedule \n"
				+ "imposed by work and school; I love to bike down the trails feeling the \n"
				+ "wind hit my sweat soaked brow. It is a challenge to get up the hill \n"
				+ "but is very much rewarded by the fun ride down! \n");
		
		System.out.println("Basic Aritmetic in Java \n");
		
		//Step A:
		//Add code that approximates the value of PI for the following cases:
		//i. Use formula #1
		//ii. Modify formula #1 to replace all 1's in formula with 1.0 (floating point)
		//iii. Modify formula #1 to where all numbers in the formula are changed to floating point
		//iv. Display value when using formula #2
		//v. Modify formula #2 to replace all 1's in formula with 1.0 (floating point)
		//vi. Modify formula #2 to where all numbers in the formula are changed to floating point
		
		//i. formula #1
		double equation1 = ( 4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) ));
		System.out.println("(i.)Pi = 4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) ) = " + equation1);
		
		//ii. formula #1 with 1's as floating points
		double equation1WithFloat = ( 4 * ( 1.0 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11) ));
		System.out.println("(ii.)Pi = 4 * ( 1.0 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - "
				+ "(1.0/11) ) = " + equation1WithFloat);
		
		//iii. formula #1 with all floating points
		double equation1AllFloat = ( 4.0 * ( 1.0 - (1.0/3.0) + (1.0/5.0) - (1.0/7.0) + (1.0/9.0) - (1.0/11.0) ));
		System.out.println("(iii.)Pi = 4.0 * ( 1.0 - (1.0/3.0) + (1.0/5.0) - (1.0/7.0) + (1.0/9.0) - "
				+ "(1.0/11.0) ) = " + equation1AllFloat);
		
		//iv. formula #2
		double equation2 = (4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) + (1/13) 
				- (1/15) + (1/17) - (1/19) + (1/21) ));
		System.out.println("(iv.)Pi = 4 * ( 1 - (1/3) + (1/5) - (1/7) + (1/9) - (1/11) + (1/13) - (1/15) "
				+ "+ (1/17) - (1/19) + (1/21) ) = " + equation2);
		
		//v. formula #2 with 1's as floating points
		double equation2WithFloat = (4 * ( 1.0 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11) + (1.0/13) 
				- (1.0/15) + (1.0/17) - (1.0/19) + (1.0/21) ));
		System.out.println("(v.)Pi = 4 * ( 1.0 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11) + (1.0/13) - "
				+ "(1.0/15) + (1.0/17) - (1.0/19) + (1.0/21) ) = " + equation2WithFloat);
		
		//vi. formula #2 with all floating points
		double equation2AllFloat = (4.0 * ( 1.0 - (1.0/3.0) + (1.0/5.0) - (1.0/7.0) + (1.0/9.0) - (1.0/11.0) + 
				(1.0/13.0) - (1.0/15.0) + (1.0/17.0) - (1.0/19.0) + (1.0/21.0) ));
		System.out.println("(vi.)Pi = 4.0 * ( 1.0 - (1.0/3.0) + (1.0/5.0) - (1.0/7.0) + (1.0/9.0) - (1.0/11.0) "
				+ "+ (1.0/13.0) - (1.0/15.0) + (1.0/17.0) - (1.0/19.0) + (1.0/21.0) ) = " + equation2AllFloat);
		
	}//main 

}//Assignment 1
