package exams;

/*
 * By: Caleb Harris
 * CS1150 - 001 (m/w) 
 * Due: April 19, 2021
 * Quiz 3
 */

public class HarrisCalebQuiz3 {

	public static void main(String[] args) {

		// part 1
		int[] numbers = { 7, 9, 1, 8, 6, 4, 2 };
		double average = computeAverage(numbers);
		System.out.printf("The average of the array values is: %.2f\n", average);

		// part2
		final int NUM_ATHLETES = 8;

		AthleteQ athlete1 = new AthleteQ("Haley Anderson", "USA", 26);
		AthleteQ athlete2 = new AthleteQ("Leonie Beck", "Germany", 2);
		AthleteQ athlete3 = new AthleteQ("Pieter Timmers", "Belgium", 5);
		AthleteQ athlete4 = new AthleteQ("Alain Bernard", "France", 7);
		AthleteQ athlete5 = new AthleteQ("Caeleb Dressel", "USA", 1);
		AthleteQ athlete6 = new AthleteQ("Katie Ledecky", "USA", 3);
		AthleteQ athlete7 = new AthleteQ("Kyle Chalmers", "Australia", 12);
		AthleteQ athlete8 = new AthleteQ("Luca Urlando", "USA", 6);

		// Create an array that holds athletes and place each athlete into the array
		AthleteQ[] athletes = new AthleteQ[NUM_ATHLETES];
		athletes[0] = athlete1;
		athletes[1] = athlete2;
		athletes[2] = athlete3;
		athletes[3] = athlete4;
		athletes[4] = athlete5;
		athletes[5] = athlete6;
		athletes[6] = athlete7;
		athletes[7] = athlete8;

		double averageRanking = computeAverage(athletes);
		System.out.printf("The average world ranking of all athletes is: %.2f\n", averageRanking);

		int numAthletes = findNumAthletes(athletes, "USA");
		System.out.println("Number of athletes from USA: " + numAthletes);

		AthleteQ[] athletesCountry = findAthletes(athletes, numAthletes, "USA");

		displayAthletes(athletesCountry);

	} // end main

	public static double computeAverage(int[] array) {

		int sum = 0;
		int numberCounter = array.length;

		for (int i = 0; i < array.length; i++) {
			sum = array[i] + sum;
		}

		double average = (double) sum / numberCounter;

		return average;

	} // end computeAverage

	public static double computeAverage(AthleteQ[] athletes) {

		int sum = 0;
		for (int i = 0; i < athletes.length; i++) {
			sum = sum + athletes[i].getWorldRanking();
		}

		double averageRanking = (double) sum / athletes.length;

		return averageRanking;

	} // end computeAverage

	public static int findNumAthletes(AthleteQ[] athletes, String country) {

		int numAthletes = 0;
		for (int i = 0; i < athletes.length; i++) {
			if (athletes[i].getCountry() == "USA") {
				numAthletes++;
			}
		}

		return numAthletes;
	} // end findNumAthletes

	public static AthleteQ[] findAthletes(AthleteQ[] athletes, int numAthletes, String country) {

		AthleteQ[] athletesCountry = new AthleteQ[numAthletes];
		int athletesOfCountryCounter = 0;
		for (int i = 0; i < athletes.length; i++) {
			if (country.equals("USA") ) {
				athletesCountry[i] = athletes[i];
				athletesOfCountryCounter++;
			}
		}

		return athletesCountry;
	} // end findAthletes

	public static void displayAthletes(AthleteQ[] athletes) {
		System.out.println(
				"\nName				Country			Ranking\n----------------------------------------------------");
		for (int i = 0; i < athletes.length; i++) {
			System.out.printf(athletes[i].getName() + "%10s", athletes[i].getCountry() + "%10s",
					athletes[i].getWorldRanking());
		}
	}

} // end HarrisCalebQuiz3

class AthleteQ {
	private String name;
	private String country;
	private int worldRanking;

	public AthleteQ(String name, String country, int worldRanking) {
		this.name = name;
		this.country = country;
		this.worldRanking = worldRanking;
	}

	public String getName() {
		return name;
	}

	public String getCountry() {
		return country;
	}

	public int getWorldRanking() {
		return worldRanking;
	}
} // AthleteQ
