package exams;

public class HarrisCalebFinal {

	   public static void main(String[] args) {

	// These are the elephants and kangaroos to be placed into the zoo
		Elephant elephant1 = new Elephant("Jumbo", "Enclosure 23");
		Elephant elephant2 = new Elephant("Titan", "Enclosure 23");
		Kangaroo kangaroo1 = new Kangaroo("Thumper", "Enclosure 17");
		Kangaroo kangaroo2 = new Kangaroo("Jack", "Enclosure 17");
		Kangaroo kangaroo3 = new Kangaroo("Sheila", "Enclosure 17");

		// Array to hold Animal objects that will be placed into the zoo
		ZooAnimal[] animals = new ZooAnimal[5];
		animals[0] = elephant1;
		animals[1] = kangaroo1;
		animals[2] = elephant2;
		animals[3] = kangaroo2;
		animals[4] = kangaroo3;

	//**** STEP 2: ADD SOLUTION FOR MAIN HERE AFTER YOU COMPLETE THE ZOO CLASS BELOW *****
	// Create a zoo, fill the zoo with the animals, print the animals in the zoo

			Zoo zoo = new Zoo ();
			zoo.fillZoo(animals);
			zoo.printZooDetails();



		// After you create and fill the zoo with animals this code proves that there
		// are no animals left in the animals array.  If you see the output "Issue!..." 
		// it means the animals array is not empty.
		System.out.println();
		for (int i = 0; i < animals.length; i++) {
		   if (animals[i] == null) {
			System.out.println("Animals [" + i + "] is empty");
		   }
		   else {
			System.out.println("Issue! Array still contains animal at index " + i);	
		   }
		}

	   } // main
	} // CS 1150 Final


	//***********************************
	// Zoo Class
	//***********************************
	class Zoo { 

	// STEP 1: Complete only this class 
		//data fields
		private int numElephants;
		private int numKangaroos;
		private ZooAnimal[] theZooAnimals;
		
		public void fillZoo(ZooAnimal[] animals) {
			
			//allocate mem for zooAnimals
			theZooAnimals = new ZooAnimal[animals.length];
			
			for (int i = 0; i < theZooAnimals.length; i++) {
				theZooAnimals[i] = animals[i];
				if (theZooAnimals[i] instanceof Kangaroo) {
					numKangaroos++;
				}
				else if (theZooAnimals[i] instanceof Elephant) {
					numElephants++;
				}
				animals[i] = null;
			}
			
		}// end fillZoo
		
		public void printZooDetails() {
			System.out.printf("Number of Kangaroos in zoo = %d\nNumber of Elephants in zoo = %d\n\n", numKangaroos, numElephants);
			System.out.println("Animals In Zoo\n---------------------------------------------------");
			for (int i = 0; i < theZooAnimals.length; i++) {
				System.out.printf("theZooAnimals[%d] = %s\nAnimal Located at: %s\n\n", i, theZooAnimals[i].getName(), theZooAnimals[i].getLocation());
			}
		}

	} // zoo


	//**************************************************
	// Given classes � ZooAnimal, Elephant, Kangaroo
	//**************************************************
	class ZooAnimal {

		private String name;
		private String location;

		public ZooAnimal(String name, String location) {
			this.name = name;
			this.location = location;
		}

		public String getName() {
			return name;
		}

		public String getLocation() {
			return location;
		}

	} // ZooAnimal


	class Elephant extends ZooAnimal {

		public Elephant(String name, String location) {
			super(name, location);
		}
		
	} // Elephant


	class Kangaroo extends ZooAnimal {

		public Kangaroo(String name, String location) {
			super(name, location);
		}

	} // Kangaroo
