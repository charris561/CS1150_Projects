package Worksheets;

import java.util.Scanner;

public class worksheet2 
{

	public static void main(String[] args) 
	{
		System.out.print("Enter a number: ");
		
		Scanner input = new Scanner (System.in);
		
		int number = input.nextInt();
		
		if (( number < 1) || ( number > 100 ))
		{
			System.out.println("Number is Less than 1 or greater than 100");
		}
		else 
		{
			System.out.println("Number is NOT less than 1 or greater than 100");
		}
		
		input.close();
		
	}
	
}
