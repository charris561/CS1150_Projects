package Worksheets;

public class worksheet9 { 

	 

	   public static void main(String[] args) { 
		  


	// Add code here to create array of 5 automobiles
		   Automobile[] automobiles = new Automobile[5];
		   SUV aFordSuv = new SUV("Ford");
		   SUV aChevySuv = new SUV("Chevy");
		   SUV aToyotaSuv = new SUV("Toyota");
		   SportsCar aBMWSportsCar = new SportsCar("BMW");
		   SportsCar aAudiSportsCar = new SportsCar("Audi");
		   automobiles[0] = aFordSuv;
		   automobiles[1] = aChevySuv;
		   automobiles[2] = aToyotaSuv;
		   automobiles[3] = aBMWSportsCar;
		   automobiles[4] = aAudiSportsCar;

	// Then iterate through the array printing the manufacturer 
		   for (int i = 0; i < automobiles.length; i++) {
			   System.out.printf("automobiles[%d] was manufactured by %s\n", i, automobiles[i].getManufacturer());
		   }
	 
	 

	   } 

	 

	  	 } //Worksheet8 

	 

	 

	class Automobile { 

	   String manufacturer; 

	 

	   public Automobile(String manufacturer) { 

	this.manufacturer = manufacturer; 

	   } 

	 

	   public String getManufacturer() { 

	return manufacturer; 

	   } 

	} 

	 

	 

	 	class SUV extends Automobile { 

	 

	   // In worksheet #8, we used the setManufacturer method to place the manufacturer 

	   // into the "manufacturer" instance variable in the parent.   

	   // In this worksheet, there is no set method in the parent but we can call the  

	   // constructor to set the "manufacturer" instance variable in the parent. 

	   public SUV(String manufacturer) { 

	super(manufacturer); 

	   } 

	   	} 

	 

	 

	 	class SportsCar extends Automobile { 

	 

	   public SportsCar(String manufacturer) { 

	super(manufacturer); 

	   } 

	} 