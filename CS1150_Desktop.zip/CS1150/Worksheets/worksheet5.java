package Worksheets;

import java.util.Scanner;

public class worksheet5 { 

	 

public static void main(String[] args) 
{ 



Scanner input = new Scanner (System.in); 



System.out.println("Enter the radius "); 

double radius = input.nextDouble(); 



System.out.println("The area of the circle = " + circleArea(radius)); 



} // main  





public static double circleArea(double radius) 
{ 

  



double area = Math.PI * Math.pow(radius, 2);


return(area);


} // circleArea 





} // Worksheet5 