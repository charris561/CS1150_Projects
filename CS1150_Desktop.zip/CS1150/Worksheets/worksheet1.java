package Worksheets;

import java.util.Scanner;

public class worksheet1 

{

	public static void main(String[] args)
	{
		
		Scanner input = new Scanner(System.in);
		
		System.out.print ("Input the radius of the circle:  ");
		
		double radiusValue = input.nextDouble();
		
		if (radiusValue >= 0)
		{
			
			System.out.println ("The area of the circle is: ");
			System.out.print( radiusValue * radiusValue * Math.PI);
			
		}
		
		else
		{
			
			System.out.println ("Invalid radius value, please"
					+ "type in a positive value");
			
		}
		
		input.close();
		
	}

}
